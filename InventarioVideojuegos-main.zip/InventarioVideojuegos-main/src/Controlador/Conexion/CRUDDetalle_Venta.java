
package Controlador.Conexion;

/**
 *
 * @author mr540
 */
public class CRUDDetalle_Venta {
    
}
