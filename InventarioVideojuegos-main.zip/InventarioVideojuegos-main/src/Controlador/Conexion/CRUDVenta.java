
package Controlador.Conexion;

/**
 *
 * @author mr540
 */
public class CRUDVenta {
    
}
